package kawa.lib;

import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.expr.QuoteExp;
import gnu.expr.SetExp;
import gnu.expr.Symbols;
import gnu.kawa.functions.AddOp;
import gnu.kawa.functions.ArithOp;
import gnu.kawa.functions.ParseFormat;
import gnu.kawa.lispexpr.LispLanguage;
import gnu.kawa.reflect.StaticFieldLocation;
import gnu.kawa.xml.XDataType;
import gnu.lists.Consumer;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.mapping.CallContext;
import gnu.mapping.Location;
import gnu.mapping.PropertySet;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Eval;
import kawa.lang.Macro;
import kawa.lang.Quote;
import kawa.lang.SyntaxForm;
import kawa.lang.SyntaxForms;
import kawa.lang.SyntaxPattern;
import kawa.lang.SyntaxRule;
import kawa.lang.SyntaxRules;
import kawa.lang.SyntaxTemplate;
import kawa.lang.TemplateScope;
import kawa.lang.Translator;
import kawa.standard.Scheme;
import kawa.standard.syntax_case;

/* compiled from: std_syntax.scm */
public class std_syntax extends ModuleBody {
    public static final Macro $Prvt$$Pccase;
    public static final Macro $Prvt$$Pccase$Mnmatch;
    public static final Macro $Prvt$$Pcdo$Mninit;
    public static final Macro $Prvt$$Pcdo$Mnlambda1;
    public static final Macro $Prvt$$Pcdo$Mnlambda2;
    public static final Macro $Prvt$$Pcdo$Mnstep;
    public static final Macro $Prvt$$Pclet$Mninit;
    public static final Macro $Prvt$$Pclet$Mnlambda1;
    public static final Macro $Prvt$$Pclet$Mnlambda2;
    public static final Location $Prvt$define;
    public static final Location $Prvt$define$Mnconstant;
    public static final Location $Prvt$if;
    public static final Location $Prvt$letrec;
    public static final std_syntax $instance;
    static final IntNum Lit0;
    static final IntNum Lit1;
    static final SimpleSymbol Lit10;
    static final SyntaxPattern Lit11;
    static final SyntaxPattern Lit12;
    static final SyntaxTemplate Lit13;
    static final SyntaxPattern Lit14;
    static final SyntaxTemplate Lit15;
    static final SimpleSymbol Lit16;
    static final SyntaxPattern Lit17;
    static final SyntaxPattern Lit18;
    static final SyntaxTemplate Lit19;
    static final SimpleSymbol Lit2;
    static final SyntaxPattern Lit20;
    static final SyntaxTemplate Lit21;
    static final SimpleSymbol Lit22;
    static final SyntaxRules Lit23;
    static final SimpleSymbol Lit24;
    static final SyntaxRules Lit25;
    static final SimpleSymbol Lit26;
    static final SyntaxRules Lit27;
    static final SimpleSymbol Lit28;
    static final SyntaxRules Lit29;
    static final SyntaxRules Lit3;
    static final SimpleSymbol Lit30;
    static final SyntaxRules Lit31;
    static final SimpleSymbol Lit32;
    static final SyntaxRules Lit33;
    static final SimpleSymbol Lit34;
    static final SyntaxRules Lit35;
    static final SimpleSymbol Lit36;
    static final SyntaxRules Lit37;
    static final SimpleSymbol Lit38;
    static final SyntaxRules Lit39;
    static final SimpleSymbol Lit4;
    static final SimpleSymbol Lit40;
    static final SyntaxRules Lit41;
    static final SimpleSymbol Lit42;
    static final SyntaxRules Lit43;
    static final SimpleSymbol Lit44;
    static final SyntaxRules Lit45;
    static final SimpleSymbol Lit46;
    static final SimpleSymbol Lit47;
    static final SimpleSymbol Lit48;
    static final SimpleSymbol Lit49;
    static final SyntaxRules Lit5;
    static final SimpleSymbol Lit50;
    static final SimpleSymbol Lit51;
    static final SimpleSymbol Lit52;
    static final SimpleSymbol Lit53;
    static final SimpleSymbol Lit54;
    static final SyntaxPattern Lit55;
    static final SimpleSymbol Lit56;
    static final SyntaxTemplate Lit57;
    static final SyntaxTemplate Lit58;
    static final SimpleSymbol Lit59;
    static final SimpleSymbol Lit6;
    static final SyntaxRules Lit60;
    static final SimpleSymbol Lit61;
    static final SyntaxRules Lit62;
    static final SimpleSymbol Lit63;
    static final SimpleSymbol Lit64;
    static final SimpleSymbol Lit65;
    static final SimpleSymbol Lit66;
    static final SimpleSymbol Lit67;
    static final SimpleSymbol Lit68;
    static final SimpleSymbol Lit69;
    static final SyntaxRules Lit7;
    static final SimpleSymbol Lit70;
    static final SimpleSymbol Lit71;
    static final SimpleSymbol Lit72;
    static final SimpleSymbol Lit73;
    static final SimpleSymbol Lit74;
    static final SimpleSymbol Lit75;
    static final SimpleSymbol Lit76;
    static final SimpleSymbol Lit77;
    static final SimpleSymbol Lit8;
    static final SyntaxRules Lit9;
    public static final Macro and;
    public static final Macro begin$Mnfor$Mnsyntax;
    public static final Macro f96case;
    public static final Macro cond;
    public static final ModuleMethod datum$Mn$Grsyntax$Mnobject;
    public static final Macro define$Mnfor$Mnsyntax;
    public static final Macro define$Mnprocedure;
    public static final Macro delay;
    public static final Macro f97do;
    public static final ModuleMethod free$Mnidentifier$Eq$Qu;
    public static final ModuleMethod generate$Mntemporaries;
    public static final ModuleMethod identifier$Qu;
    public static final Macro let;
    public static final Macro let$St;
    public static final Macro or;
    public static final ModuleMethod syntax$Mncolumn;
    public static final ModuleMethod syntax$Mnline;
    public static final ModuleMethod syntax$Mnobject$Mn$Grdatum;
    public static final ModuleMethod syntax$Mnsource;
    public static final Macro with$Mnsyntax;

    static {
        Lit77 = (SimpleSymbol) new SimpleSymbol("temp").readResolve();
        Lit76 = (SimpleSymbol) new SimpleSymbol("=>").readResolve();
        Lit75 = (SimpleSymbol) new SimpleSymbol("else").readResolve();
        Lit74 = (SimpleSymbol) new SimpleSymbol("eqv?").readResolve();
        Lit73 = (SimpleSymbol) new SimpleSymbol("x").readResolve();
        Lit72 = (SimpleSymbol) new SimpleSymbol("if").readResolve();
        Lit71 = (SimpleSymbol) new SimpleSymbol("letrec").readResolve();
        Lit70 = (SimpleSymbol) new SimpleSymbol("%let").readResolve();
        Lit69 = (SimpleSymbol) new SimpleSymbol("%syntax-error").readResolve();
        Lit68 = (SimpleSymbol) new SimpleSymbol("lambda").readResolve();
        Lit67 = (SimpleSymbol) new SimpleSymbol("make").readResolve();
        Lit66 = (SimpleSymbol) new SimpleSymbol(LispLanguage.quote_sym).readResolve();
        Lit65 = (SimpleSymbol) new SimpleSymbol("<gnu.expr.GenericProc>").readResolve();
        Lit64 = (SimpleSymbol) new SimpleSymbol("::").readResolve();
        Lit63 = (SimpleSymbol) new SimpleSymbol("syntax-case").readResolve();
        Object[] objArr = new Object[1];
        SimpleSymbol simpleSymbol = (SimpleSymbol) new SimpleSymbol("with-syntax").readResolve();
        Lit61 = simpleSymbol;
        objArr[0] = simpleSymbol;
        SyntaxRule[] syntaxRuleArr = new SyntaxRule[3];
        Object[] objArr2 = new Object[1];
        SimpleSymbol simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("begin").readResolve();
        Lit56 = simpleSymbol2;
        objArr2[0] = simpleSymbol2;
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\f\u0007\r\u000f\b\b\b", new Object[0], 2), "\u0001\u0003", "\u0011\u0018\u0004\t\u0003\b\r\u000b", objArr2, 1);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018<,\f\u0007\f\u000f\b\b\f\u0017\r\u001f\u0018\b\b", new Object[0], 4), "\u0001\u0001\u0001\u0003", "\u0011\u0018\u0004\t\u000b\t\u0010\b\t\u0003\b\u0011\u0018\f\t\u0013\b\u001d\u001b", new Object[]{Lit63, Lit56}, 1);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018L-\f\u0007\f\u000f\b\u0000\u0010\b\f\u0017\r\u001f\u0018\b\b", new Object[0], 4), "\u0003\u0003\u0001\u0003", "\u0011\u0018\u00041\u0011\u0018\f\b\r\u000b\t\u0010\b\u0019\b\u0005\u0003\b\u0011\u0018\u0014\t\u0013\b\u001d\u001b", new Object[]{Lit63, (SimpleSymbol) new SimpleSymbol("list").readResolve(), Lit56}, 1);
        Lit62 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("define-for-syntax").readResolve();
        Lit59 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[1];
        objArr2 = new Object[2];
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("begin-for-syntax").readResolve();
        Lit54 = simpleSymbol2;
        objArr2[0] = simpleSymbol2;
        objArr2[1] = (SimpleSymbol) new SimpleSymbol("define").readResolve();
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\u0003", new Object[0], 1), "\u0000", "\u0011\u0018\u0004\b\u0011\u0018\f\u0002", objArr2, 0);
        Lit60 = new SyntaxRules(objArr, syntaxRuleArr, 1);
        Lit58 = new SyntaxTemplate("\u0001\u0000", "\u0018\u0004", new Object[]{Values.empty}, 0);
        Lit57 = new SyntaxTemplate("\u0001\u0000", "\n", new Object[0], 0);
        Lit55 = new SyntaxPattern("\f\u0007\u000b", new Object[0], 2);
        Lit53 = (SimpleSymbol) new SimpleSymbol("syntax-column").readResolve();
        Lit52 = (SimpleSymbol) new SimpleSymbol("syntax-line").readResolve();
        Lit51 = (SimpleSymbol) new SimpleSymbol("syntax-source").readResolve();
        Lit50 = (SimpleSymbol) new SimpleSymbol("free-identifier=?").readResolve();
        Lit49 = (SimpleSymbol) new SimpleSymbol("identifier?").readResolve();
        Lit48 = (SimpleSymbol) new SimpleSymbol("generate-temporaries").readResolve();
        Lit47 = (SimpleSymbol) new SimpleSymbol("datum->syntax-object").readResolve();
        Lit46 = (SimpleSymbol) new SimpleSymbol("syntax-object->datum").readResolve();
        objArr = new Object[3];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("define-procedure").readResolve();
        Lit44 = simpleSymbol;
        objArr[0] = simpleSymbol;
        objArr[1] = Lit64;
        objArr[2] = Lit65;
        syntaxRuleArr = new SyntaxRule[1];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\r\u000f\b\b\b", new Object[0], 2), "\u0001\u0003", "\u0011\u0018\u0004\u00c1\u0011\u0018\f\t\u0003\u0011\u0018\u0014\u0011\u0018\u001c\b\u0011\u0018$\u0011\u0018\u001c\b\u0011\u0018,\b\u0003\b\u0011\u00184\t\u0003\u0011\u0018<\b\u0011\u0018D\b\r\u000b", new Object[]{Lit56, (SimpleSymbol) new SimpleSymbol("define-constant").readResolve(), Lit64, Lit65, Lit67, Lit66, (SimpleSymbol) new SimpleSymbol("invoke").readResolve(), PairWithPosition.make(Lit66, PairWithPosition.make((SimpleSymbol) new SimpleSymbol("setProperties").readResolve(), LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 1024020), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 1024020), (SimpleSymbol) new SimpleSymbol("java.lang.Object[]").readResolve()}, 1);
        Lit45 = new SyntaxRules(objArr, syntaxRuleArr, 2);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("delay").readResolve();
        Lit42 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[1];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\b", new Object[0], 1), "\u0001", "\u0011\u0018\u0004\u0011\u0018\f\b\u0011\u0018\u0014\t\u0010\b\u0003", new Object[]{Lit67, (SimpleSymbol) new SimpleSymbol("<kawa.lang.Promise>").readResolve(), Lit68}, 0);
        Lit43 = new SyntaxRules(objArr, syntaxRuleArr, 1);
        objArr = new Object[2];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("do").readResolve();
        Lit40 = simpleSymbol;
        objArr[0] = simpleSymbol;
        objArr[1] = Lit64;
        syntaxRuleArr = new SyntaxRule[1];
        objArr2 = new Object[9];
        objArr2[0] = Lit71;
        objArr2[1] = (SimpleSymbol) new SimpleSymbol("%do%loop").readResolve();
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("%do-lambda1").readResolve();
        Lit36 = simpleSymbol2;
        objArr2[2] = simpleSymbol2;
        objArr2[3] = Lit72;
        objArr2[4] = (SimpleSymbol) new SimpleSymbol("not").readResolve();
        objArr2[5] = Lit56;
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("%do-step").readResolve();
        Lit32 = simpleSymbol2;
        objArr2[6] = simpleSymbol2;
        objArr2[7] = Values.empty;
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("%do-init").readResolve();
        Lit34 = simpleSymbol2;
        objArr2[8] = simpleSymbol2;
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018,\r\u0007\u0000\b\b\u001c\f\u000f\u0013\r\u001f\u0018\b\b", new Object[0], 4), "\u0003\u0001\u0000\u0003", "\u0011\u0018\u0004\u0189\b\u0011\u0018\f\b\u0011\u0018\u0014\u0019\b\u0005\u0003\t\u0010\b\u0011\u0018\u001c)\u0011\u0018$\b\u000b\u0081\u0011\u0018,\u0011\u001d\u001b\b\u0011\u0018\f\b\u0005\u0011\u00184\u0003\b\u0011\u0018,\u0011\u0018<\u0012\b\u0011\u0018\f\b\u0005\u0011\u0018D\b\u0003", objArr2, 1);
        Lit41 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("%do-lambda2").readResolve();
        Lit38 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[2];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\u000b\f\u0017\f\u001f\b", new Object[0], 4), "\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\n\u0019\t\u0003\u0013\b\u001b", new Object[]{Lit38}, 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0011\u0018\u0004\t\u0003\b\u000b", new Object[]{Lit68}, 0);
        Lit39 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[]{Lit36, Lit64};
        syntaxRuleArr = new SyntaxRule[5];
        objArr2 = new Object[]{Lit36, Lit64};
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018l\\\f\u0007\f\u0002\f\u000f\f\u0017\f\u001f\b#\f/\f7\b", new Object[]{Lit64}, 7), "\u0001\u0001\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\"I9\t\u0003\u0011\u0018\f\b\u000b+\b3", objArr2, 0);
        objArr2 = new Object[]{Lit36, Lit64};
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\\L\f\u0007\f\u0002\f\u000f\f\u0017\b\u001b\f'\f/\b", new Object[]{Lit64}, 6), "\u0001\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u001aI9\t\u0003\u0011\u0018\f\b\u000b#\b+", objArr2, 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018L<\f\u0007\f\u000f\f\u0017\b\u001b\f'\f/\b", new Object[0], 6), "\u0001\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u001a\u0019\t\u0003#\b+", new Object[]{Lit36}, 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018<,\f\u0007\f\u000f\b\u0013\f\u001f\f'\b", new Object[0], 5), "\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u0012\u0019\t\u0003\u001b\b#", new Object[]{Lit36}, 0);
        syntaxRuleArr[4] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0011\u0018\u0004\t\u0003\t\u0010\b\u000b", new Object[]{Lit38}, 0);
        Lit37 = new SyntaxRules(objArr, syntaxRuleArr, 7);
        objArr = new Object[]{Lit34, Lit64};
        syntaxRuleArr = new SyntaxRule[7];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\\\f\u0007\f\u0002\f\u000f\f\u0017\f\u001f\b\b", new Object[]{Lit64}, 4), "\u0001\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u0002\f\u000f\f\u0017\b\b", new Object[]{Lit64}, 3), "\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018<\f\u0007\f\u000f\f\u0017\b\b", new Object[0], 3), "\u0001\u0001\u0001", "\u000b", new Object[0], 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018,\f\u0007\f\u000f\b\b", new Object[0], 2), "\u0001\u0001", "\u000b", new Object[0], 0);
        syntaxRuleArr[4] = new SyntaxRule(new SyntaxPattern("\f\u0018<\f\u0007\f\u000f\f\u0017\b\b", new Object[0], 3), "\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[5] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\b\b", new Object[0], 1), "\u0001", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("do binding with no value", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 794643), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 794628)}, 0);
        syntaxRuleArr[6] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u000f\f\u0017\f\u001f\b\b", new Object[0], 4), "\u0001\u0001\u0001\u0001", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("do binding must have syntax: (var [:: type] init [step])", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 806917), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 802820)}, 0);
        Lit35 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[]{Lit32, Lit64};
        syntaxRuleArr = new SyntaxRule[4];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u0002\f\u000f\f\u0017\f\u001f\b", new Object[]{Lit64}, 4), "\u0001\u0001\u0001\u0001", "\u001b", new Object[0], 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u0002\f\u000f\f\u0017\b", new Object[]{Lit64}, 3), "\u0001\u0001\u0001", "\u0003", new Object[0], 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u000f\f\u0017\b", new Object[0], 3), "\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0003", new Object[0], 0);
        Lit33 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("let*").readResolve();
        Lit30 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[5];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\u0003", new Object[0], 1), "\u0000", "\u0011\u0018\u0004\t\u0010\u0002", new Object[]{Lit70}, 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\b\u000b", new Object[0], 2), "\u0001\u0000", "\u0011\u0018\u0004\u0011\b\u0003\n", new Object[]{Lit70}, 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\u000b\u0013", new Object[0], 3), "\u0001\u0000\u0000", "\u0011\u0018\u0004\u0011\b\u0003\b\u0011\u0018\f\t\n\u0012", new Object[]{Lit70, Lit30}, 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\u000b", new Object[0], 2), "\u0001\u0000", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("invalid bindings list in let*", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 679943), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 675846)}, 0);
        syntaxRuleArr[4] = new SyntaxRule(new SyntaxPattern("\f\u0018\u0003", new Object[0], 1), "\u0000", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("missing bindings list in let*", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 692231), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 688134)}, 0);
        Lit31 = new SyntaxRules(objArr, syntaxRuleArr, 3);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("let").readResolve();
        Lit28 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[2];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018,\r\u0007\u0000\b\b\u000b", new Object[0], 2), "\u0003\u0000", "\u0011\u0018\u0004\u0019\b\u0005\u0003\n", new Object[]{Lit70}, 1);
        objArr2 = new Object[3];
        objArr2[0] = Lit71;
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("%let-lambda1").readResolve();
        Lit22 = simpleSymbol2;
        objArr2[1] = simpleSymbol2;
        simpleSymbol2 = (SimpleSymbol) new SimpleSymbol("%let-init").readResolve();
        Lit26 = simpleSymbol2;
        objArr2[2] = simpleSymbol2;
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007,\r\u000f\b\b\b\u0013", new Object[0], 3), "\u0001\u0003\u0000", "\u00a9\u0011\u0018\u0004y\b\t\u0003\b\u0011\u0018\f\u0019\b\r\u000b\t\u0010\b\u0012\b\u0003\b\r\u0011\u0018\u0014\b\u000b", objArr2, 1);
        Lit29 = new SyntaxRules(objArr, syntaxRuleArr, 3);
        objArr = new Object[]{Lit26, Lit64};
        syntaxRuleArr = new SyntaxRule[5];
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u0002\f\u000f\f\u0017\b\b", new Object[]{Lit64}, 3), "\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018<\f\u0007\f\u000f\f\u0017\b\b", new Object[0], 3), "\u0001\u0001\u0001", "\u0013", new Object[0], 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\b\b", new Object[0], 1), "\u0001", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("let binding with no value", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 552979), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 552964)}, 0);
        syntaxRuleArr[4] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u000f\f\u0017\f\u001f\b\b", new Object[0], 4), "\u0001\u0001\u0001\u0001", "\u0018\u0004", new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("let binding must have syntax: (var [type] init)", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 565253), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 561156)}, 0);
        Lit27 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("%let-lambda2").readResolve();
        Lit24 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[2];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\u000b\f\u0017\f\u001f\b", new Object[0], 4), "\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\n\u0019\t\u0003\u0013\b\u001b", new Object[]{Lit24}, 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0011\u0018\u0004\t\u0003\u000b", new Object[]{Lit68}, 0);
        Lit25 = new SyntaxRules(objArr, syntaxRuleArr, 4);
        objArr = new Object[]{Lit22, Lit64};
        syntaxRuleArr = new SyntaxRule[4];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018L<\f\u0007\f\u000f\f\u0017\b\u001b\f'\f/\b", new Object[0], 6), "\u0001\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u001a1!\t\u0003\b\u000b#\b+", new Object[]{Lit22}, 0);
        objArr2 = new Object[]{Lit22};
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\\L\f\u0007\f\u0002\f\u000f\f\u0017\b\u001b\f'\f/\b", new Object[]{Lit64}, 6), "\u0001\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u001a1!\t\u0003\b\u000b#\b+", objArr2, 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018<,\f\u0007\f\u000f\b\u0013\f\u001f\f'\b", new Object[0], 5), "\u0001\u0001\u0000\u0001\u0001", "\u0011\u0018\u0004\t\u0012\u0019\t\u0003\u001b\b#", new Object[]{Lit22}, 0);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\b\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0011\u0018\u0004\t\u0003\t\u0010\b\u000b", new Object[]{Lit24}, 0);
        Lit23 = new SyntaxRules(objArr, syntaxRuleArr, 6);
        Lit21 = new SyntaxTemplate("\u0001\u0001\u0003", "\u0011\u0018\u00041\b\u0011\u0018\f\b\u000b\b\u0011\u0018\u0014\u0011\u0018\f\u0011\u0018\f\b\t\u0003\b\u0015\u0013", new Object[]{Lit70, Lit73, Lit72}, 1);
        Lit20 = new SyntaxPattern("\f\u0007\f\u000f\r\u0017\u0010\b\b", new Object[0], 3);
        Lit19 = new SyntaxTemplate("\u0001\u0001", "\u000b", new Object[0], 0);
        Lit18 = new SyntaxPattern("\f\u0007\f\u000f\b", new Object[0], 2);
        Lit17 = new SyntaxPattern("\f\u0007\b", new Object[0], 1);
        Lit16 = (SimpleSymbol) new SimpleSymbol("or").readResolve();
        Lit15 = new SyntaxTemplate("\u0001\u0001\u0003", "\u0011\u0018\u00041\b\u0011\u0018\f\b\u000b\b\u0011\u0018\u0014\u0011\u0018\f)\t\u0003\b\u0015\u0013\u0018\u001c", new Object[]{Lit70, Lit73, Lit72, PairWithPosition.make(Lit73, LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 385052)}, 1);
        Lit14 = new SyntaxPattern("\f\u0007\f\u000f\r\u0017\u0010\b\b", new Object[0], 3);
        Lit13 = new SyntaxTemplate("\u0001\u0001", "\u000b", new Object[0], 0);
        Lit12 = new SyntaxPattern("\f\u0007\f\u000f\b", new Object[0], 2);
        Lit11 = new SyntaxPattern("\f\u0007\b", new Object[0], 1);
        Lit10 = (SimpleSymbol) new SimpleSymbol("and").readResolve();
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("%case-match").readResolve();
        Lit8 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[2];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u000f\b", new Object[0], 2), "\u0001\u0001", "\u0011\u0018\u0004\t\u0003\b\u0011\u0018\f\b\u000b", new Object[]{Lit74, Lit66}, 0);
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\f\u000f\r\u0017\u0010\b\b", new Object[0], 3), "\u0001\u0001\u0003", "\u0011\u0018\u0004Y\u0011\u0018\f\t\u0003\b\u0011\u0018\u0014\b\u000b\b\u0011\u0018\u001c\t\u0003\b\u0015\u0013", new Object[]{Lit16, Lit74, Lit66, Lit8}, 1);
        Lit9 = new SyntaxRules(objArr, syntaxRuleArr, 3);
        objArr = new Object[2];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("%case").readResolve();
        Lit6 = simpleSymbol;
        objArr[0] = simpleSymbol;
        objArr[1] = Lit75;
        syntaxRuleArr = new SyntaxRule[4];
        objArr2 = new Object[]{Lit56};
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007<\f\u0002\r\u000f\b\b\b\b", new Object[]{Lit75}, 2), "\u0001\u0003", "\u0011\u0018\u0004\b\r\u000b", objArr2, 1);
        objArr2 = new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("junk following else (in case)", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 241674), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 237577)};
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007<\f\u0002\r\u000f\b\b\b\u0013", new Object[]{Lit75}, 3), "\u0001\u0003\u0000", "\u0018\u0004", objArr2, 0);
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\\,\r\u000f\b\b\b\r\u0017\u0010\b\b\b", new Object[0], 3), "\u0001\u0003\u0003", "\u0011\u0018\u0004A\u0011\u0018\f\t\u0003\b\r\u000b\b\u0011\u0018\u0014\b\u0015\u0013", new Object[]{Lit72, Lit8, Lit56}, 1);
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\\,\r\u000f\b\b\b\r\u0017\u0010\b\b\f\u001f\r' \b\b", new Object[0], 5), "\u0001\u0003\u0003\u0001\u0003", "\u0011\u0018\u0004A\u0011\u0018\f\t\u0003\b\r\u000b1\u0011\u0018\u0014\b\u0015\u0013\b\u0011\u0018\u001c\t\u0003\t\u001b\b%#", new Object[]{Lit72, Lit8, Lit56, Lit6}, 1);
        Lit7 = new SyntaxRules(objArr, syntaxRuleArr, 5);
        objArr = new Object[1];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("case").readResolve();
        Lit4 = simpleSymbol;
        objArr[0] = simpleSymbol;
        syntaxRuleArr = new SyntaxRule[1];
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018\f\u0007\r\u000f\b\b\b", new Object[0], 2), "\u0001\u0003", "\u0011\u0018\u00041\b\u0011\u0018\f\b\u0003\b\u0011\u0018\u0014\u0011\u0018\f\b\r\u000b", new Object[]{Lit70, (SimpleSymbol) new SimpleSymbol("tmp").readResolve(), Lit6}, 1);
        Lit5 = new SyntaxRules(objArr, syntaxRuleArr, 2);
        objArr = new Object[3];
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("cond").readResolve();
        Lit2 = simpleSymbol;
        objArr[0] = simpleSymbol;
        objArr[1] = Lit75;
        objArr[2] = Lit76;
        syntaxRuleArr = new SyntaxRule[8];
        objArr2 = new Object[]{Lit56};
        syntaxRuleArr[0] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0002\f\u0007\r\u000f\b\b\b\b", new Object[]{Lit75}, 2), "\u0001\u0003", "\u0011\u0018\u0004\t\u0003\b\r\u000b", objArr2, 1);
        objArr2 = new Object[]{PairWithPosition.make(Lit69, PairWithPosition.make("else clause must be last clause of cond", LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 86035), "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 86020)};
        syntaxRuleArr[1] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0002\f\u0007\r\u000f\b\b\b\r\u0017\u0010\b\b", new Object[]{Lit75}, 3), "\u0001\u0003\u0003", "\u0018\u0004", objArr2, 0);
        objArr2 = new Object[]{Lit70, Lit77, Lit72, PairWithPosition.make(Lit77, LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 102423)};
        syntaxRuleArr[2] = new SyntaxRule(new SyntaxPattern("\f\u0018<\f\u0007\f\u0002\f\u000f\b\b", new Object[]{Lit76}, 2), "\u0001\u0001", "\u0011\u0018\u00041\b\u0011\u0018\f\b\u0003\b\u0011\u0018\u0014\u0011\u0018\f\b\t\u000b\u0018\u001c", objArr2, 0);
        objArr2 = new Object[]{Lit70, Lit77, Lit72, PairWithPosition.make(Lit77, LList.Empty, "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm", 122898), Lit2};
        syntaxRuleArr[3] = new SyntaxRule(new SyntaxPattern("\f\u0018<\f\u0007\f\u0002\f\u000f\b\f\u0017\r\u001f\u0018\b\b", new Object[]{Lit76}, 4), "\u0001\u0001\u0001\u0003", "\u0011\u0018\u00041\b\u0011\u0018\f\b\u0003\b\u0011\u0018\u0014\u0011\u0018\f!\t\u000b\u0018\u001c\b\u0011\u0018$\t\u0013\b\u001d\u001b", objArr2, 1);
        syntaxRuleArr[4] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\b\b", new Object[0], 1), "\u0001", "\u0003", new Object[0], 0);
        syntaxRuleArr[5] = new SyntaxRule(new SyntaxPattern("\f\u0018\u001c\f\u0007\b\f\u000f\r\u0017\u0010\b\b", new Object[0], 3), "\u0001\u0001\u0003", "\u0011\u0018\u0004\t\u0003\b\u0011\u0018\f\t\u000b\b\u0015\u0013", new Object[]{Lit16, Lit2}, 1);
        syntaxRuleArr[6] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u000f\r\u0017\u0010\b\b\b", new Object[0], 3), "\u0001\u0001\u0003", "\u0011\u0018\u0004\t\u0003\b\u0011\u0018\f\t\u000b\b\u0015\u0013", new Object[]{Lit72, Lit56}, 1);
        syntaxRuleArr[7] = new SyntaxRule(new SyntaxPattern("\f\u0018L\f\u0007\f\u000f\r\u0017\u0010\b\b\f\u001f\r' \b\b", new Object[0], 5), "\u0001\u0001\u0003\u0001\u0003", "\u0011\u0018\u0004\t\u0003A\u0011\u0018\f\t\u000b\b\u0015\u0013\b\u0011\u0018\u0014\t\u001b\b%#", new Object[]{Lit72, Lit56, Lit2}, 1);
        Lit3 = new SyntaxRules(objArr, syntaxRuleArr, 5);
        Lit1 = IntNum.make(1);
        Lit0 = IntNum.make(0);
        $instance = new std_syntax();
        $Prvt$define = StaticFieldLocation.make("kawa.lib.prim_syntax", "define");
        $Prvt$define$Mnconstant = StaticFieldLocation.make("kawa.lib.prim_syntax", "define$Mnconstant");
        $Prvt$if = StaticFieldLocation.make("kawa.lib.prim_syntax", "if");
        $Prvt$letrec = StaticFieldLocation.make("kawa.lib.prim_syntax", "letrec");
        cond = Macro.make(Lit2, Lit3, $instance);
        f96case = Macro.make(Lit4, Lit5, $instance);
        $Prvt$$Pccase = Macro.make(Lit6, Lit7, $instance);
        $Prvt$$Pccase$Mnmatch = Macro.make(Lit8, Lit9, $instance);
        simpleSymbol = Lit10;
        ModuleBody moduleBody = $instance;
        and = Macro.make(simpleSymbol, new ModuleMethod(moduleBody, 1, null, 4097), $instance);
        or = Macro.make(Lit16, new ModuleMethod(moduleBody, 2, null, 4097), $instance);
        $Prvt$$Pclet$Mnlambda1 = Macro.make(Lit22, Lit23, $instance);
        $Prvt$$Pclet$Mnlambda2 = Macro.make(Lit24, Lit25, $instance);
        $Prvt$$Pclet$Mninit = Macro.make(Lit26, Lit27, $instance);
        let = Macro.make(Lit28, Lit29, $instance);
        let$St = Macro.make(Lit30, Lit31, $instance);
        $Prvt$$Pcdo$Mnstep = Macro.make(Lit32, Lit33, $instance);
        $Prvt$$Pcdo$Mninit = Macro.make(Lit34, Lit35, $instance);
        $Prvt$$Pcdo$Mnlambda1 = Macro.make(Lit36, Lit37, $instance);
        $Prvt$$Pcdo$Mnlambda2 = Macro.make(Lit38, Lit39, $instance);
        f97do = Macro.make(Lit40, Lit41, $instance);
        delay = Macro.make(Lit42, Lit43, $instance);
        define$Mnprocedure = Macro.make(Lit44, Lit45, $instance);
        syntax$Mnobject$Mn$Grdatum = new ModuleMethod(moduleBody, 3, Lit46, 4097);
        datum$Mn$Grsyntax$Mnobject = new ModuleMethod(moduleBody, 4, Lit47, 8194);
        generate$Mntemporaries = new ModuleMethod(moduleBody, 5, Lit48, 4097);
        identifier$Qu = new ModuleMethod(moduleBody, 6, Lit49, 4097);
        free$Mnidentifier$Eq$Qu = new ModuleMethod(moduleBody, 7, Lit50, 8194);
        syntax$Mnsource = new ModuleMethod(moduleBody, 8, Lit51, 4097);
        syntax$Mnline = new ModuleMethod(moduleBody, 9, Lit52, 4097);
        syntax$Mncolumn = new ModuleMethod(moduleBody, 10, Lit53, 4097);
        simpleSymbol = Lit54;
        PropertySet moduleMethod = new ModuleMethod(moduleBody, 11, null, 4097);
        moduleMethod.setProperty("source-location", "/u2/home/jis/ai2-kawa/kawa/lib/std_syntax.scm:298");
        begin$Mnfor$Mnsyntax = Macro.make(simpleSymbol, moduleMethod, $instance);
        define$Mnfor$Mnsyntax = Macro.make(Lit59, Lit60, $instance);
        with$Mnsyntax = Macro.make(Lit61, Lit62, $instance);
        $instance.run();
    }

    public std_syntax() {
        ModuleInfo.register(this);
    }

    public final void run(CallContext $ctx) {
        Consumer $result = $ctx.consumer;
    }

    static Object lambda1(Object f) {
        Object[] allocVars = SyntaxPattern.allocVars(3, null);
        if (Lit11.match(f, allocVars, 0)) {
            return new QuoteExp(Language.getDefaultLanguage().booleanObject(true));
        }
        if (Lit12.match(f, allocVars, 0)) {
            return Lit13.execute(allocVars, TemplateScope.make());
        } else if (!Lit14.match(f, allocVars, 0)) {
            return syntax_case.error("syntax-case", f);
        } else {
            return Lit15.execute(allocVars, TemplateScope.make());
        }
    }

    static Object lambda2(Object f) {
        Object[] allocVars = SyntaxPattern.allocVars(3, null);
        if (Lit17.match(f, allocVars, 0)) {
            return new QuoteExp(Language.getDefaultLanguage().booleanObject(false));
        }
        if (Lit18.match(f, allocVars, 0)) {
            return Lit19.execute(allocVars, TemplateScope.make());
        } else if (!Lit20.match(f, allocVars, 0)) {
            return syntax_case.error("syntax-case", f);
        } else {
            return Lit21.execute(allocVars, TemplateScope.make());
        }
    }

    public static Object syntaxObject$To$Datum(Object obj) {
        return Quote.quote(obj);
    }

    public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
        switch (moduleMethod.selector) {
            case ParseFormat.SEEN_MINUS /*1*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case SetExp.DEFINING_FLAG /*2*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case ArithOp.DIVIDE_INEXACT /*5*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case ArithOp.QUOTIENT /*6*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case SetExp.PREFER_BINDING2 /*8*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case ArithOp.ASHIFT_GENERAL /*9*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case ArithOp.ASHIFT_LEFT /*10*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            case ArithOp.ASHIFT_RIGHT /*11*/:
                callContext.value1 = obj;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            default:
                return super.match1(moduleMethod, obj, callContext);
        }
    }

    public static Object datum$To$SyntaxObject(Object template$Mnidentifier, Object obj) {
        return SyntaxForms.makeWithTemplate(template$Mnidentifier, obj);
    }

    public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
        switch (moduleMethod.selector) {
            case SetExp.GLOBAL_FLAG /*4*/:
                callContext.value1 = obj;
                callContext.value2 = obj2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            case ArithOp.QUOTIENT_EXACT /*7*/:
                callContext.value1 = obj;
                callContext.value2 = obj2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            default:
                return super.match2(moduleMethod, obj, obj2, callContext);
        }
    }

    public static Object generateTemporaries(Object list) {
        Object n = Integer.valueOf(Translator.listLength(list));
        Object obj = LList.Empty;
        while (Scheme.numEqu.apply2(n, Lit0) == Boolean.FALSE) {
            n = AddOp.$Mn.apply2(n, Lit1);
            Pair pair = new Pair(datum$To$SyntaxObject(list, Symbols.gentemp()), obj);
        }
        return obj;
    }

    public static boolean isIdentifier(Object form) {
        boolean x = form instanceof Symbol;
        if (x) {
            return x;
        }
        x = form instanceof SyntaxForm;
        if (!x) {
            return x;
        }
        try {
            return SyntaxForms.isIdentifier((SyntaxForm) form);
        } catch (ClassCastException e) {
            throw new WrongType(e, "kawa.lang.SyntaxForms.isIdentifier(kawa.lang.SyntaxForm)", 1, form);
        }
    }

    public static boolean isFreeIdentifier$Eq(Object id1, Object id2) {
        try {
            try {
                return SyntaxForms.freeIdentifierEquals((SyntaxForm) id1, (SyntaxForm) id2);
            } catch (ClassCastException e) {
                throw new WrongType(e, "kawa.lang.SyntaxForms.freeIdentifierEquals(kawa.lang.SyntaxForm,kawa.lang.SyntaxForm)", 2, id2);
            }
        } catch (ClassCastException e2) {
            throw new WrongType(e2, "kawa.lang.SyntaxForms.freeIdentifierEquals(kawa.lang.SyntaxForm,kawa.lang.SyntaxForm)", 1, id1);
        }
    }

    public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
        switch (moduleMethod.selector) {
            case SetExp.GLOBAL_FLAG /*4*/:
                return datum$To$SyntaxObject(obj, obj2);
            case ArithOp.QUOTIENT_EXACT /*7*/:
                return isFreeIdentifier$Eq(obj, obj2) ? Boolean.TRUE : Boolean.FALSE;
            default:
                return super.apply2(moduleMethod, obj, obj2);
        }
    }

    public static Object syntaxSource(Object form) {
        if (form instanceof SyntaxForm) {
            return syntaxSource(((SyntaxForm) form).getDatum());
        }
        if (!(form instanceof PairWithPosition)) {
            return Boolean.FALSE;
        }
        Object str = ((PairWithPosition) form).getFileName();
        return str == null ? Boolean.FALSE : str;
    }

    public static Object syntaxLine(Object form) {
        if (form instanceof SyntaxForm) {
            return syntaxLine(((SyntaxForm) form).getDatum());
        }
        return form instanceof PairWithPosition ? Integer.valueOf(((PairWithPosition) form).getLineNumber()) : Boolean.FALSE;
    }

    public static Object syntaxColumn(Object form) {
        if (form instanceof SyntaxForm) {
            return syntaxLine(((SyntaxForm) form).getDatum());
        }
        return form instanceof PairWithPosition ? Integer.valueOf(((PairWithPosition) form).getColumnNumber() + 0) : Boolean.FALSE;
    }

    static Object lambda3(Object form) {
        Object[] allocVars = SyntaxPattern.allocVars(2, null);
        if (Lit55.match(form, allocVars, 0)) {
            if (Eval.eval.apply1(syntaxObject$To$Datum(new Pair(Lit56, Lit57.execute(allocVars, TemplateScope.make())))) != Boolean.FALSE) {
                return Lit58.execute(allocVars, TemplateScope.make());
            }
        }
        return syntax_case.error("syntax-case", form);
    }

    public Object apply1(ModuleMethod moduleMethod, Object obj) {
        switch (moduleMethod.selector) {
            case ParseFormat.SEEN_MINUS /*1*/:
                return lambda1(obj);
            case SetExp.DEFINING_FLAG /*2*/:
                return lambda2(obj);
            case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                return syntaxObject$To$Datum(obj);
            case ArithOp.DIVIDE_INEXACT /*5*/:
                return generateTemporaries(obj);
            case ArithOp.QUOTIENT /*6*/:
                return isIdentifier(obj) ? Boolean.TRUE : Boolean.FALSE;
            case SetExp.PREFER_BINDING2 /*8*/:
                return syntaxSource(obj);
            case ArithOp.ASHIFT_GENERAL /*9*/:
                return syntaxLine(obj);
            case ArithOp.ASHIFT_LEFT /*10*/:
                return syntaxColumn(obj);
            case ArithOp.ASHIFT_RIGHT /*11*/:
                return lambda3(obj);
            default:
                return super.apply1(moduleMethod, obj);
        }
    }
}
