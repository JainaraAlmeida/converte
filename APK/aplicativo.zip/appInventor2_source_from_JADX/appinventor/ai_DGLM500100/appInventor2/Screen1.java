package appinventor.ai_DGLM500100.appInventor2;

import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListPicker;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.expr.SetExp;
import gnu.kawa.functions.ArithOp;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.ParseFormat;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.kawa.xml.ElementType;
import gnu.kawa.xml.XDataType;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.Sequence;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.PropertySet;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import kawa.standard.require;

/* compiled from: Screen1.yail */
public class Screen1 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit12;
    static final IntNum Lit13;
    static final SimpleSymbol Lit14;
    static final SimpleSymbol Lit15;
    static final PairWithPosition Lit16;
    static final PairWithPosition Lit17;
    static final PairWithPosition Lit18;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final FString Lit21;
    static final SimpleSymbol Lit22;
    static final IntNum Lit23;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit25;
    static final SimpleSymbol Lit26;
    static final IntNum Lit27;
    static final SimpleSymbol Lit28;
    static final IntNum Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final IntNum Lit31;
    static final SimpleSymbol Lit32;
    static final IntNum Lit33;
    static final SimpleSymbol Lit34;
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit36;
    static final IntNum Lit37;
    static final FString Lit38;
    static final FString Lit39;
    static final SimpleSymbol Lit4;
    static final SimpleSymbol Lit40;
    static final SimpleSymbol Lit41;
    static final FString Lit42;
    static final FString Lit43;
    static final SimpleSymbol Lit44;
    static final IntNum Lit45;
    static final IntNum Lit46;
    static final IntNum Lit47;
    static final IntNum Lit48;
    static final FString Lit49;
    static final PairWithPosition Lit5;
    static final SimpleSymbol Lit50;
    static final PairWithPosition Lit51;
    static final PairWithPosition Lit52;
    static final PairWithPosition Lit53;
    static final SimpleSymbol Lit54;
    static final SimpleSymbol Lit55;
    static final FString Lit56;
    static final FString Lit57;
    static final FString Lit58;
    static final SimpleSymbol Lit59;
    static final PairWithPosition Lit6;
    static final IntNum Lit60;
    static final IntNum Lit61;
    static final FString Lit62;
    static final PairWithPosition Lit63;
    static final PairWithPosition Lit64;
    static final PairWithPosition Lit65;
    static final SimpleSymbol Lit66;
    static final SimpleSymbol Lit67;
    static final SimpleSymbol Lit68;
    static final SimpleSymbol Lit69;
    static final SimpleSymbol Lit7;
    static final SimpleSymbol Lit70;
    static final SimpleSymbol Lit71;
    static final SimpleSymbol Lit72;
    static final SimpleSymbol Lit73;
    static final SimpleSymbol Lit74;
    static final SimpleSymbol Lit75;
    static final SimpleSymbol Lit76;
    static final SimpleSymbol Lit77;
    static final SimpleSymbol Lit78;
    static final SimpleSymbol Lit79;
    static final IntNum Lit8;
    static final SimpleSymbol Lit80;
    static final SimpleSymbol Lit9;
    public static Screen1 Screen1;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public Button BN_inBinario;
    public final ModuleMethod BN_inBinario$Click;
    public Button BN_inTesto;
    public final ModuleMethod BN_inTesto$Click;
    public Label Label1;
    public final ModuleMethod Screen1$Initialize;
    public TextBox TB_binario;
    public TextBox TB_testo;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    /* compiled from: Screen1.yail */
    public class frame extends ModuleBody {
        Screen1 $main;

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            switch (moduleMethod.selector) {
                case ParseFormat.SEEN_MINUS /*1*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.DIVIDE_INEXACT /*5*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.ASHIFT_LEFT /*10*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.ASHIFT_RIGHT /*11*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case ArithOp.LSHIFT_RIGHT /*12*/:
                    if (!(obj instanceof Screen1)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case Sequence.INT_S16_VALUE /*20*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case Sequence.TEXT_BYTE_VALUE /*28*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                case Sequence.DOCUMENT_VALUE /*34*/:
                    callContext.value1 = obj;
                    callContext.proc = moduleMethod;
                    callContext.pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod, obj, callContext);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            switch (moduleMethod.selector) {
                case SetExp.DEFINING_FLAG /*2*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.QUOTIENT /*6*/:
                    if (!(obj instanceof Symbol)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.QUOTIENT_EXACT /*7*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.ASHIFT_GENERAL /*9*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                case ArithOp.IOR /*14*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.proc = moduleMethod;
                    callContext.pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod, obj, obj2, callContext);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            switch (moduleMethod.selector) {
                case SetExp.PREFER_BINDING2 /*8*/:
                    callContext.value1 = obj;
                    callContext.value2 = obj2;
                    callContext.value3 = obj3;
                    callContext.value4 = obj4;
                    callContext.proc = moduleMethod;
                    callContext.pc = 4;
                    return 0;
                case ArithOp.AND /*13*/:
                    if (!(obj instanceof Screen1)) {
                        return -786431;
                    }
                    callContext.value1 = obj;
                    if (!(obj2 instanceof Component)) {
                        return -786430;
                    }
                    callContext.value2 = obj2;
                    if (!(obj3 instanceof String)) {
                        return -786429;
                    }
                    callContext.value3 = obj3;
                    if (!(obj4 instanceof String)) {
                        return -786428;
                    }
                    callContext.value4 = obj4;
                    callContext.proc = moduleMethod;
                    callContext.pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod, obj, obj2, obj3, obj4, callContext);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            switch (moduleMethod.selector) {
                case ParseFormat.SEEN_MINUS /*1*/:
                    this.$main.androidLogForm(obj);
                    return Values.empty;
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj);
                    } catch (ClassCastException e) {
                        throw new WrongType(e, "lookup-in-form-environment", 1, obj);
                    }
                case ArithOp.DIVIDE_INEXACT /*5*/:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        throw new WrongType(e2, "is-bound-in-form-environment", 1, obj);
                    }
                case ArithOp.ASHIFT_LEFT /*10*/:
                    this.$main.addToFormDoAfterCreation(obj);
                    return Values.empty;
                case ArithOp.ASHIFT_RIGHT /*11*/:
                    this.$main.sendError(obj);
                    return Values.empty;
                case ArithOp.LSHIFT_RIGHT /*12*/:
                    this.$main.processException(obj);
                    return Values.empty;
                case Sequence.INT_S16_VALUE /*20*/:
                    return Screen1.lambda6(obj);
                case Sequence.TEXT_BYTE_VALUE /*28*/:
                    return Screen1.lambda13(obj);
                case Sequence.DOCUMENT_VALUE /*34*/:
                    return Screen1.lambda18(obj);
                default:
                    return super.apply1(moduleMethod, obj);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            switch (moduleMethod.selector) {
                case SetExp.PREFER_BINDING2 /*8*/:
                    this.$main.addToComponents(obj, obj2, obj3, obj4);
                    return Values.empty;
                case ArithOp.AND /*13*/:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj, (String) obj2, (String) obj3, (Object[]) obj4) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    throw new WrongType(e, "dispatchEvent", 4, obj4);
                                }
                            } catch (ClassCastException e2) {
                                throw new WrongType(e2, "dispatchEvent", 3, obj3);
                            }
                        } catch (ClassCastException e22) {
                            throw new WrongType(e22, "dispatchEvent", 2, obj2);
                        }
                    } catch (ClassCastException e222) {
                        throw new WrongType(e222, "dispatchEvent", 1, obj);
                    }
                default:
                    return super.apply4(moduleMethod, obj, obj2, obj3, obj4);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            switch (moduleMethod.selector) {
                case SetExp.DEFINING_FLAG /*2*/:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj, obj2);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        throw new WrongType(e, "add-to-form-environment", 1, obj);
                    }
                case XDataType.ANY_ATOMIC_TYPE_CODE /*3*/:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj, obj2);
                    } catch (ClassCastException e2) {
                        throw new WrongType(e2, "lookup-in-form-environment", 1, obj);
                    }
                case ArithOp.QUOTIENT /*6*/:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj, obj2);
                        return Values.empty;
                    } catch (ClassCastException e22) {
                        throw new WrongType(e22, "add-to-global-var-environment", 1, obj);
                    }
                case ArithOp.QUOTIENT_EXACT /*7*/:
                    this.$main.addToEvents(obj, obj2);
                    return Values.empty;
                case ArithOp.ASHIFT_GENERAL /*9*/:
                    this.$main.addToGlobalVars(obj, obj2);
                    return Values.empty;
                case ArithOp.IOR /*14*/:
                    return this.$main.lookupHandler(obj, obj2);
                default:
                    return super.apply2(moduleMethod, obj, obj2);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            switch (moduleMethod.selector) {
                case ArithOp.XOR /*15*/:
                    return Screen1.lambda2();
                case SetExp.PROCEDURE /*16*/:
                    this.$main.$define();
                    return Values.empty;
                case Sequence.INT_U8_VALUE /*17*/:
                    return Screen1.lambda3();
                case Sequence.INT_S8_VALUE /*18*/:
                    return Screen1.lambda4();
                case Sequence.INT_U16_VALUE /*19*/:
                    return Screen1.lambda5();
                case Sequence.INT_U32_VALUE /*21*/:
                    return this.$main.Screen1$Initialize();
                case Sequence.INT_S32_VALUE /*22*/:
                    return Screen1.lambda7();
                case Sequence.INT_U64_VALUE /*23*/:
                    return Screen1.lambda8();
                case Sequence.INT_S64_VALUE /*24*/:
                    return Screen1.lambda9();
                case Sequence.FLOAT_VALUE /*25*/:
                    return Screen1.lambda10();
                case Sequence.DOUBLE_VALUE /*26*/:
                    return Screen1.lambda11();
                case Sequence.BOOLEAN_VALUE /*27*/:
                    return Screen1.lambda12();
                case Sequence.CHAR_VALUE /*29*/:
                    return this.$main.BN_inBinario$Click();
                case XDataType.DAY_TIME_DURATION_TYPE_CODE /*30*/:
                    return Screen1.lambda14();
                case Sequence.CDATA_VALUE /*31*/:
                    return Screen1.lambda15();
                case SetExp.SET_IF_UNBOUND /*32*/:
                    return Screen1.lambda16();
                case Sequence.ELEMENT_VALUE /*33*/:
                    return Screen1.lambda17();
                case Sequence.ATTRIBUTE_VALUE /*35*/:
                    return this.$main.BN_inTesto$Click();
                default:
                    return super.apply0(moduleMethod);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            switch (moduleMethod.selector) {
                case ArithOp.XOR /*15*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case SetExp.PROCEDURE /*16*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U8_VALUE /*17*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S8_VALUE /*18*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U16_VALUE /*19*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U32_VALUE /*21*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S32_VALUE /*22*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_U64_VALUE /*23*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.INT_S64_VALUE /*24*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.FLOAT_VALUE /*25*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.DOUBLE_VALUE /*26*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.BOOLEAN_VALUE /*27*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.CHAR_VALUE /*29*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case XDataType.DAY_TIME_DURATION_TYPE_CODE /*30*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.CDATA_VALUE /*31*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case SetExp.SET_IF_UNBOUND /*32*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.ELEMENT_VALUE /*33*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                case Sequence.ATTRIBUTE_VALUE /*35*/:
                    callContext.proc = moduleMethod;
                    callContext.pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod, callContext);
            }
        }
    }

    static {
        Lit80 = (SimpleSymbol) new SimpleSymbol("any").readResolve();
        Lit79 = (SimpleSymbol) new SimpleSymbol("list").readResolve();
        Lit78 = (SimpleSymbol) new SimpleSymbol("lookup-handler").readResolve();
        Lit77 = (SimpleSymbol) new SimpleSymbol("dispatchEvent").readResolve();
        Lit76 = (SimpleSymbol) new SimpleSymbol("send-error").readResolve();
        Lit75 = (SimpleSymbol) new SimpleSymbol("add-to-form-do-after-creation").readResolve();
        Lit74 = (SimpleSymbol) new SimpleSymbol("add-to-global-vars").readResolve();
        Lit73 = (SimpleSymbol) new SimpleSymbol("add-to-components").readResolve();
        Lit72 = (SimpleSymbol) new SimpleSymbol("add-to-events").readResolve();
        Lit71 = (SimpleSymbol) new SimpleSymbol("add-to-global-var-environment").readResolve();
        Lit70 = (SimpleSymbol) new SimpleSymbol("is-bound-in-form-environment").readResolve();
        Lit69 = (SimpleSymbol) new SimpleSymbol("lookup-in-form-environment").readResolve();
        Lit68 = (SimpleSymbol) new SimpleSymbol("add-to-form-environment").readResolve();
        Lit67 = (SimpleSymbol) new SimpleSymbol("android-log-form").readResolve();
        Lit66 = (SimpleSymbol) new SimpleSymbol("BN_inTesto$Click").readResolve();
        SimpleSymbol simpleSymbol = (SimpleSymbol) new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT).readResolve();
        Lit11 = simpleSymbol;
        Lit65 = PairWithPosition.make(simpleSymbol, PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369148), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369143), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369137);
        SimpleSymbol simpleSymbol2 = Lit79;
        simpleSymbol = (SimpleSymbol) new SimpleSymbol("number").readResolve();
        Lit9 = simpleSymbol;
        Lit64 = PairWithPosition.make(simpleSymbol2, PairWithPosition.make(simpleSymbol, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369107), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369101);
        Lit63 = PairWithPosition.make(Lit80, PairWithPosition.make(Lit79, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369076), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 369071);
        Lit62 = new FString("com.google.appinventor.components.runtime.Button");
        int[] iArr = new int[2];
        iArr[0] = ListPicker.DEFAULT_ITEM_BACKGROUND_COLOR;
        Lit61 = IntNum.make(iArr);
        Lit60 = IntNum.make(-1008);
        Lit59 = (SimpleSymbol) new SimpleSymbol("BN_inTesto").readResolve();
        Lit58 = new FString("com.google.appinventor.components.runtime.Button");
        Lit57 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit56 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit55 = (SimpleSymbol) new SimpleSymbol("Click").readResolve();
        Lit54 = (SimpleSymbol) new SimpleSymbol("BN_inBinario$Click").readResolve();
        Lit53 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270868), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270863), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270857);
        Lit52 = PairWithPosition.make(Lit79, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270827), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270821);
        Lit51 = PairWithPosition.make(Lit80, PairWithPosition.make(Lit79, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270796), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 270791);
        Lit50 = (SimpleSymbol) new SimpleSymbol("TB_binario").readResolve();
        Lit49 = new FString("com.google.appinventor.components.runtime.Button");
        iArr = new int[2];
        iArr[0] = ListPicker.DEFAULT_ITEM_BACKGROUND_COLOR;
        Lit48 = IntNum.make(iArr);
        Lit47 = IntNum.make(-1099);
        Lit46 = IntNum.make(-1008);
        Lit45 = IntNum.make(16);
        Lit44 = (SimpleSymbol) new SimpleSymbol("BN_inBinario").readResolve();
        Lit43 = new FString("com.google.appinventor.components.runtime.Button");
        Lit42 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit41 = (SimpleSymbol) new SimpleSymbol("Hint").readResolve();
        Lit40 = (SimpleSymbol) new SimpleSymbol("TB_testo").readResolve();
        Lit39 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit38 = new FString("com.google.appinventor.components.runtime.Label");
        iArr = new int[2];
        iArr[0] = -1;
        Lit37 = IntNum.make(iArr);
        Lit36 = (SimpleSymbol) new SimpleSymbol("TextColor").readResolve();
        Lit35 = (SimpleSymbol) new SimpleSymbol("TextAlignment").readResolve();
        Lit34 = (SimpleSymbol) new SimpleSymbol("Text").readResolve();
        Lit33 = IntNum.make(-2);
        Lit32 = (SimpleSymbol) new SimpleSymbol("Width").readResolve();
        Lit31 = IntNum.make(-1008);
        Lit30 = (SimpleSymbol) new SimpleSymbol("Height").readResolve();
        Lit29 = IntNum.make(1);
        Lit28 = (SimpleSymbol) new SimpleSymbol("FontTypeface").readResolve();
        Lit27 = IntNum.make(30);
        Lit26 = (SimpleSymbol) new SimpleSymbol("FontSize").readResolve();
        Lit25 = (SimpleSymbol) new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN).readResolve();
        Lit24 = (SimpleSymbol) new SimpleSymbol("FontBold").readResolve();
        iArr = new int[2];
        iArr[0] = ListPicker.DEFAULT_ITEM_BACKGROUND_COLOR;
        Lit23 = IntNum.make(iArr);
        Lit22 = (SimpleSymbol) new SimpleSymbol("Label1").readResolve();
        Lit21 = new FString("com.google.appinventor.components.runtime.Label");
        Lit20 = (SimpleSymbol) new SimpleSymbol("Initialize").readResolve();
        Lit19 = (SimpleSymbol) new SimpleSymbol("Screen1$Initialize").readResolve();
        Lit18 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 79131), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 79125);
        Lit17 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 79011), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 79006), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 79000);
        Lit16 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 78856), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 78851), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 78845);
        Lit15 = (SimpleSymbol) new SimpleSymbol("$lettera").readResolve();
        Lit14 = (SimpleSymbol) new SimpleSymbol("Title").readResolve();
        iArr = new int[2];
        iArr[0] = Component.COLOR_DKGRAY;
        Lit13 = IntNum.make(iArr);
        Lit12 = (SimpleSymbol) new SimpleSymbol("BackgroundColor").readResolve();
        Lit10 = (SimpleSymbol) new SimpleSymbol("AppName").readResolve();
        Lit8 = IntNum.make(3);
        Lit7 = (SimpleSymbol) new SimpleSymbol("AlignHorizontal").readResolve();
        Lit6 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 37042), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 37036);
        Lit5 = PairWithPosition.make(Lit11, PairWithPosition.make(Lit11, LList.Empty, "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 37042), "/tmp/1476894408893_0.39618066335586033-0/youngandroidproject/../src/appinventor/ai_DGLM500100/appInventor2/Screen1.yail", 37036);
        Lit4 = (SimpleSymbol) new SimpleSymbol("g$Letter").readResolve();
        Lit3 = (SimpleSymbol) new SimpleSymbol("g$code").readResolve();
        Lit2 = (SimpleSymbol) new SimpleSymbol("*the-null-value*").readResolve();
        Lit1 = (SimpleSymbol) new SimpleSymbol("getMessage").readResolve();
        Lit0 = (SimpleSymbol) new SimpleSymbol("Screen1").readResolve();
    }

    public Screen1() {
        ModuleInfo.register(this);
        ModuleBody appinventor_ai_DGLM500100_appInventor2_Screen1_frame = new frame();
        appinventor_ai_DGLM500100_appInventor2_Screen1_frame.$main = this;
        this.android$Mnlog$Mnform = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 1, Lit67, 4097);
        this.add$Mnto$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 2, Lit68, 8194);
        this.lookup$Mnin$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 3, Lit69, 8193);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 5, Lit70, 4097);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 6, Lit71, 8194);
        this.add$Mnto$Mnevents = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 7, Lit72, 8194);
        this.add$Mnto$Mncomponents = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 8, Lit73, 16388);
        this.add$Mnto$Mnglobal$Mnvars = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 9, Lit74, 8194);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 10, Lit75, 4097);
        this.send$Mnerror = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 11, Lit76, 4097);
        this.process$Mnexception = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 12, "process-exception", 4097);
        this.dispatchEvent = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 13, Lit77, 16388);
        this.lookup$Mnhandler = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 14, Lit78, 8194);
        PropertySet moduleMethod = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 15, null, 0);
        moduleMethod.setProperty("source-location", "/tmp/runtime1156071432215537040.scm:547");
        lambda$Fn1 = moduleMethod;
        this.$define = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 16, "$define", 0);
        lambda$Fn2 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 17, null, 0);
        lambda$Fn3 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 18, null, 0);
        lambda$Fn4 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 19, null, 0);
        lambda$Fn5 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 20, null, 4097);
        this.Screen1$Initialize = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 21, Lit19, 0);
        lambda$Fn6 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 22, null, 0);
        lambda$Fn7 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 23, null, 0);
        lambda$Fn8 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 24, null, 0);
        lambda$Fn9 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 25, null, 0);
        lambda$Fn10 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 26, null, 0);
        lambda$Fn11 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 27, null, 0);
        lambda$Fn12 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 28, null, 4097);
        this.BN_inBinario$Click = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 29, Lit54, 0);
        lambda$Fn13 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 30, null, 0);
        lambda$Fn14 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 31, null, 0);
        lambda$Fn15 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 32, null, 0);
        lambda$Fn16 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 33, null, 0);
        lambda$Fn17 = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 34, null, 4097);
        this.BN_inTesto$Click = new ModuleMethod(appinventor_ai_DGLM500100_appInventor2_Screen1_frame, 35, Lit66, 0);
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        Consumer $result = $ctx.consumer;
        Object find = require.find("com.google.youngandroid.runtime");
        try {
            String str;
            ((Runnable) find).run();
            this.$Stdebug$Mnform$St = Boolean.FALSE;
            this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
            FString stringAppend = strings.stringAppend(misc.symbol$To$String(Lit0), "-global-vars");
            if (stringAppend == null) {
                str = null;
            } else {
                str = stringAppend.toString();
            }
            this.global$Mnvar$Mnenvironment = Environment.make(str);
            Screen1 = null;
            this.form$Mnname$Mnsymbol = Lit0;
            this.events$Mnto$Mnregister = LList.Empty;
            this.components$Mnto$Mncreate = LList.Empty;
            this.global$Mnvars$Mnto$Mncreate = LList.Empty;
            this.form$Mndo$Mnafter$Mncreation = LList.Empty;
            find = require.find("com.google.youngandroid.runtime");
            try {
                ((Runnable) find).run();
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addGlobalVarToCurrentFormEnvironment(Lit3, "Bem Vindo"), $result);
                } else {
                    addToGlobalVars(Lit3, lambda$Fn2);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addGlobalVarToCurrentFormEnvironment(Lit4, runtime.callYailPrimitive(runtime.string$Mnsplit, LList.list2("a b c d f g h l m n o p q r s t u v w x y z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z", ElementType.MATCH_ANY_LOCALNAME), Lit5, "split")), $result);
                } else {
                    addToGlobalVars(Lit4, lambda$Fn3);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit7, Lit8, Lit9);
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "appInventor2", Lit11);
                    runtime.setAndCoerceProperty$Ex(Lit0, Lit12, Lit13, Lit9);
                    Values.writeValues(runtime.setAndCoerceProperty$Ex(Lit0, Lit14, "Screen1", Lit11), $result);
                } else {
                    addToFormDoAfterCreation(new Promise(lambda$Fn4));
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit19, this.Screen1$Initialize);
                } else {
                    addToFormEnvironment(Lit19, this.Screen1$Initialize);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "Screen1", "Initialize");
                } else {
                    addToEvents(Lit0, Lit20);
                }
                this.Label1 = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit21, Lit22, lambda$Fn6), $result);
                } else {
                    addToComponents(Lit0, Lit38, Lit22, lambda$Fn7);
                }
                this.TB_testo = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit39, Lit40, lambda$Fn8), $result);
                } else {
                    addToComponents(Lit0, Lit42, Lit40, lambda$Fn9);
                }
                this.BN_inBinario = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit43, Lit44, lambda$Fn10), $result);
                } else {
                    addToComponents(Lit0, Lit49, Lit44, lambda$Fn11);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit54, this.BN_inBinario$Click);
                } else {
                    addToFormEnvironment(Lit54, this.BN_inBinario$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "BN_inBinario", "Click");
                } else {
                    addToEvents(Lit44, Lit55);
                }
                this.TB_binario = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit56, Lit50, lambda$Fn13), $result);
                } else {
                    addToComponents(Lit0, Lit57, Lit50, lambda$Fn14);
                }
                this.BN_inTesto = null;
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(runtime.addComponentWithinRepl(Lit0, Lit58, Lit59, lambda$Fn15), $result);
                } else {
                    addToComponents(Lit0, Lit62, Lit59, lambda$Fn16);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    runtime.addToCurrentFormEnvironment(Lit66, this.BN_inTesto$Click);
                } else {
                    addToFormEnvironment(Lit66, this.BN_inTesto$Click);
                }
                if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) runtime.$Stthis$Mnform$St, "BN_inTesto", "Click");
                } else {
                    addToEvents(Lit59, Lit55);
                }
                runtime.initRuntime();
            } catch (ClassCastException e) {
                throw new WrongType(e, "java.lang.Runnable.run()", 1, find);
            }
        } catch (ClassCastException e2) {
            throw new WrongType(e2, "java.lang.Runnable.run()", 1, find);
        }
    }

    static String lambda3() {
        return "Bem Vindo";
    }

    static Object lambda4() {
        return runtime.callYailPrimitive(runtime.string$Mnsplit, LList.list2("a b c d f g h l m n o p q r s t u v w x y z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z", ElementType.MATCH_ANY_LOCALNAME), Lit6, "split");
    }

    static Object lambda5() {
        runtime.setAndCoerceProperty$Ex(Lit0, Lit7, Lit8, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "appInventor2", Lit11);
        runtime.setAndCoerceProperty$Ex(Lit0, Lit12, Lit13, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit0, Lit14, "Screen1", Lit11);
    }

    public Object Screen1$Initialize() {
        runtime.setThisForm();
        runtime.addGlobalVarToCurrentFormEnvironment(Lit3, "a\t01100001 b\t01100010 c\t01100011 d\t01100100 e\t01100101 f\t01100110 g\t01100111 h\t01101000 i\t01101001 j\t01101010 k\t01101011 l\t01101100 m\t01101101 n\t01101110 o\t01101111 p\t01110000 q\t01110001 r\t01110010 s\t01110011 t\t01110100 u\t01110101 v\t01110110 w\t01110111 x\t01111000 y\t01111001 z\t01111010\t01111010 A\t01000001 B\t01000010 C\t01000011 D\t01000100 E\t01000101 F\t01000110 G\t01000111 H\t01001000 I\t01001001 J\t01001010 K\t01001011 L\t01001100 M\t01001101 N\t01001110 O\t01001111 P\t01010000 Q\t01010001 R\t01010010 S\t01010011 T\t01010100 U\t01010101 V\t01010110 W\t01010111 X\t01011000 Y\t01011001 Z\t01011010");
        runtime.yailForEach(lambda$Fn5, runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, runtime.$Stthe$Mnnull$Mnvalue$St));
        runtime.addGlobalVarToCurrentFormEnvironment(Lit3, runtime.callYailPrimitive(runtime.string$Mnreplace$Mnall, LList.list3(runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St), ElementType.MATCH_ANY_LOCALNAME, ElementType.MATCH_ANY_LOCALNAME), Lit17, "replace all"));
        return runtime.addGlobalVarToCurrentFormEnvironment(Lit3, runtime.callYailPrimitive(runtime.string$Mnsplit, LList.list2(runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St), ElementType.MATCH_ANY_LOCALNAME), Lit18, "split"));
    }

    static Object lambda6(Object $lettera) {
        Symbol symbol = Lit3;
        ModuleMethod moduleMethod = runtime.string$Mnreplace$Mnall;
        Object lookupGlobalVarInCurrentFormEnvironment = runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($lettera instanceof Package) {
            $lettera = runtime.signalRuntimeError(strings.stringAppend("The variable ", ((Procedure) runtime.get$Mndisplay$Mnrepresentation).apply1(Lit15), " is not bound in the current context"), "Unbound Variable");
        }
        return runtime.addGlobalVarToCurrentFormEnvironment(symbol, runtime.callYailPrimitive(moduleMethod, LList.list3(lookupGlobalVarInCurrentFormEnvironment, $lettera, ElementType.MATCH_ANY_LOCALNAME), Lit16, "replace all"));
    }

    static Object lambda7() {
        runtime.setAndCoerceProperty$Ex(Lit22, Lit12, Lit23, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit24, Boolean.TRUE, Lit25);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit26, Lit27, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit28, Lit29, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit30, Lit31, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit32, Lit33, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit34, "Converte", Lit11);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit35, Lit29, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit22, Lit36, Lit37, Lit9);
    }

    static Object lambda8() {
        runtime.setAndCoerceProperty$Ex(Lit22, Lit12, Lit23, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit24, Boolean.TRUE, Lit25);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit26, Lit27, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit28, Lit29, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit30, Lit31, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit32, Lit33, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit34, "Converte", Lit11);
        runtime.setAndCoerceProperty$Ex(Lit22, Lit35, Lit29, Lit9);
        return runtime.setAndCoerceProperty$Ex(Lit22, Lit36, Lit37, Lit9);
    }

    static Object lambda10() {
        return runtime.setAndCoerceProperty$Ex(Lit40, Lit41, "Hint for TextBox1", Lit11);
    }

    static Object lambda9() {
        return runtime.setAndCoerceProperty$Ex(Lit40, Lit41, "Hint for TextBox1", Lit11);
    }

    static Object lambda11() {
        runtime.setAndCoerceProperty$Ex(Lit44, Lit26, Lit45, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit30, Lit46, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit32, Lit47, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit34, "Converter em bin\u00e1rio", Lit11);
        return runtime.setAndCoerceProperty$Ex(Lit44, Lit36, Lit48, Lit9);
    }

    static Object lambda12() {
        runtime.setAndCoerceProperty$Ex(Lit44, Lit26, Lit45, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit30, Lit46, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit32, Lit47, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit44, Lit34, "Converter em bin\u00e1rio", Lit11);
        return runtime.setAndCoerceProperty$Ex(Lit44, Lit36, Lit48, Lit9);
    }

    public Object BN_inBinario$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit50, Lit34, runtime.getProperty$1(Lit40, Lit34), Lit11);
        return runtime.yailForEach(lambda$Fn12, runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, runtime.$Stthe$Mnnull$Mnvalue$St));
    }

    static Object lambda13(Object $lettera) {
        Object signalRuntimeError;
        SimpleSymbol simpleSymbol = Lit50;
        SimpleSymbol simpleSymbol2 = Lit34;
        ModuleMethod moduleMethod = runtime.string$Mnreplace$Mnall;
        Object property$1 = runtime.getProperty$1(Lit50, Lit34);
        if ($lettera instanceof Package) {
            signalRuntimeError = runtime.signalRuntimeError(strings.stringAppend("The variable ", ((Procedure) runtime.get$Mndisplay$Mnrepresentation).apply1(Lit15), " is not bound in the current context"), "Unbound Variable");
        } else {
            signalRuntimeError = $lettera;
        }
        ModuleMethod moduleMethod2 = runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment = runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod3 = runtime.yail$Mnlist$Mnindex;
        if ($lettera instanceof Package) {
            $lettera = runtime.signalRuntimeError(strings.stringAppend("The variable ", ((Procedure) runtime.get$Mndisplay$Mnrepresentation).apply1(Lit15), " is not bound in the current context"), "Unbound Variable");
        }
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, runtime.callYailPrimitive(moduleMethod, LList.list3(property$1, signalRuntimeError, runtime.callYailPrimitive(moduleMethod2, LList.list2(lookupGlobalVarInCurrentFormEnvironment, runtime.callYailPrimitive(moduleMethod3, LList.list2($lettera, runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, runtime.$Stthe$Mnnull$Mnvalue$St)), Lit51, "index in list")), Lit52, "select list item")), Lit53, "replace all"), Lit11);
    }

    static Object lambda14() {
        return runtime.setAndCoerceProperty$Ex(Lit50, Lit41, "Hint for TextBox2", Lit11);
    }

    static Object lambda15() {
        return runtime.setAndCoerceProperty$Ex(Lit50, Lit41, "Hint for TextBox2", Lit11);
    }

    static Object lambda16() {
        runtime.setAndCoerceProperty$Ex(Lit59, Lit26, Lit45, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit30, Lit60, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit32, Lit33, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit34, "Mostrar original", Lit11);
        return runtime.setAndCoerceProperty$Ex(Lit59, Lit36, Lit61, Lit9);
    }

    static Object lambda17() {
        runtime.setAndCoerceProperty$Ex(Lit59, Lit26, Lit45, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit30, Lit60, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit32, Lit33, Lit9);
        runtime.setAndCoerceProperty$Ex(Lit59, Lit34, "Mostrar original", Lit11);
        return runtime.setAndCoerceProperty$Ex(Lit59, Lit36, Lit61, Lit9);
    }

    public Object BN_inTesto$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit40, Lit34, runtime.getProperty$1(Lit50, Lit34), Lit11);
        return runtime.yailForEach(lambda$Fn17, runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St));
    }

    static Object lambda18(Object $cod) {
        return runtime.setAndCoerceProperty$Ex(Lit40, Lit34, runtime.callYailPrimitive(runtime.string$Mnreplace$Mnall, LList.list3(runtime.getProperty$1(Lit40, Lit34), runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St), runtime.callYailPrimitive(runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, runtime.$Stthe$Mnnull$Mnvalue$St), runtime.callYailPrimitive(runtime.yail$Mnlist$Mnindex, LList.list2(runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St), runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St)), Lit63, "index in list")), Lit64, "select list item")), Lit65, "replace all"), Lit11);
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol name, Object object) {
        androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", name, this.form$Mnenvironment, object));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol name, Object default$Mnvalue) {
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & 1;
        if (x) {
            if (!this.form$Mnenvironment.isBound(name)) {
                return default$Mnvalue;
            }
        } else if (!x) {
            return default$Mnvalue;
        }
        return this.form$Mnenvironment.get(name);
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol name, Object object) {
        androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", name, this.global$Mnvar$Mnenvironment, object));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = lists.cons(lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        RetValManager.sendError(error == null ? null : error.toString());
    }

    public void processException(Object ex) {
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component componentObject, String registeredComponentName, String eventName, Object[] args) {
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            return false;
        } else if (lookupInFormEnvironment(registeredObject) != componentObject) {
            return false;
        } else {
            try {
                Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                return true;
            } catch (Throwable exception) {
                androidLogForm(exception.getMessage());
                exception.printStackTrace();
                processException(exception);
                return false;
            }
        }
    }

    public Object lookupHandler(Object componentName, Object eventName) {
        String str = null;
        String obj = componentName == null ? null : componentName.toString();
        if (eventName != null) {
            str = eventName.toString();
        }
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj, str)));
    }

    public void $define() {
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception exception) {
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen1 = this;
        addToFormEnvironment(Lit0, this);
        Object obj = this.events$Mnto$Mnregister;
        while (obj != LList.Empty) {
            try {
                Pair arg0 = (Pair) obj;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = lists.car.apply1(event$Mninfo);
                String obj2 = apply1 == null ? null : apply1.toString();
                Object apply12 = lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj2, apply12 == null ? null : apply12.toString());
                obj = arg0.getCdr();
            } catch (ClassCastException e) {
                throw new WrongType(e, "arg0", -2, obj);
            }
        }
        addToGlobalVars(Lit2, lambda$Fn1);
        Screen1 closureEnv = this;
        obj = lists.reverse(this.global$Mnvars$Mnto$Mncreate);
        while (obj != LList.Empty) {
            try {
                arg0 = (Pair) obj;
                Object var$Mnval = arg0.getCar();
                Object var = lists.car.apply1(var$Mnval);
                addToGlobalVarEnvironment((Symbol) var, Scheme.applyToArgs.apply1(lists.cadr.apply1(var$Mnval)));
                obj = arg0.getCdr();
            } catch (ClassCastException e2) {
                throw new WrongType(e2, "arg0", -2, obj);
            } catch (ClassCastException e22) {
                throw new WrongType(e22, "arg0", -2, obj);
            } catch (ClassCastException e222) {
                throw new WrongType(e222, "add-to-form-environment", 0, component$Mnname);
            } catch (ClassCastException e3) {
                throw new WrongType(e3, "lookup-in-form-environment", 0, apply1);
            } catch (ClassCastException e2222) {
                throw new WrongType(e2222, "arg0", -2, obj);
            } catch (ClassCastException e22222) {
                throw new WrongType(e22222, "arg0", -2, obj);
            } catch (ClassCastException e222222) {
                throw new WrongType(e222222, "add-to-global-var-environment", 0, var);
            } catch (ClassCastException e2222222) {
                throw new WrongType(e2222222, "arg0", -2, obj);
            } catch (YailRuntimeError exception2) {
                processException(exception2);
                return;
            }
        }
        obj = lists.reverse(this.form$Mndo$Mnafter$Mncreation);
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            misc.force(arg0.getCar());
            obj = arg0.getCdr();
        }
        LList component$Mndescriptors = lists.reverse(this.components$Mnto$Mncreate);
        closureEnv = this;
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            Object component$Mninfo = arg0.getCar();
            Object component$Mnname = lists.caddr.apply1(component$Mninfo);
            lists.cadddr.apply1(component$Mninfo);
            Object component$Mnobject = Invoke.make.apply2(lists.cadr.apply1(component$Mninfo), lookupInFormEnvironment((Symbol) lists.car.apply1(component$Mninfo)));
            SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
            addToFormEnvironment((Symbol) component$Mnname, component$Mnobject);
            obj = arg0.getCdr();
        }
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            component$Mninfo = arg0.getCar();
            lists.caddr.apply1(component$Mninfo);
            Boolean init$Mnthunk = lists.cadddr.apply1(component$Mninfo);
            if (init$Mnthunk != Boolean.FALSE) {
                Scheme.applyToArgs.apply1(init$Mnthunk);
            }
            obj = arg0.getCdr();
        }
        obj = component$Mndescriptors;
        while (obj != LList.Empty) {
            arg0 = (Pair) obj;
            component$Mninfo = arg0.getCar();
            component$Mnname = lists.caddr.apply1(component$Mninfo);
            lists.cadddr.apply1(component$Mninfo);
            callInitialize(SlotGet.field.apply2(this, component$Mnname));
            obj = arg0.getCdr();
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Object car;
        LList symbols = LList.makeList(argsArray, 0);
        Procedure procedure = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Pair result = LList.Empty;
        Object arg0 = symbols;
        while (arg0 != LList.Empty) {
            try {
                Pair arg02 = (Pair) arg0;
                Object arg03 = arg02.getCdr();
                car = arg02.getCar();
                try {
                    result = Pair.make(misc.symbol$To$String((Symbol) car), result);
                    arg0 = arg03;
                } catch (ClassCastException e) {
                    throw new WrongType(e, "symbol->string", 1, car);
                }
            } catch (ClassCastException e2) {
                throw new WrongType(e2, "arg0", -2, arg0);
            }
        }
        car = procedure.apply2(moduleMethod, LList.reverseInPlace(result));
        try {
            return misc.string$To$Symbol((CharSequence) car);
        } catch (ClassCastException e3) {
            throw new WrongType(e3, "string->symbol", 1, car);
        }
    }

    static Object lambda2() {
        return null;
    }
}
