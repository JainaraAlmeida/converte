package gnu.lists;

public interface NodePredicate extends ItemPredicate {
}
