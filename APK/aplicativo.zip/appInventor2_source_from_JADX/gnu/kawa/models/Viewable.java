package gnu.kawa.models;

public interface Viewable {
    void makeView(Display display, Object obj);
}
