package com.google.appinventor.components.runtime;

public interface AlarmHandler {
    void alarm();
}
