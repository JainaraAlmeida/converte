package com.google.appinventor.components.runtime;

import android.content.Intent;

public interface OnNewIntentListener {
    void onNewIntent(Intent intent);
}
