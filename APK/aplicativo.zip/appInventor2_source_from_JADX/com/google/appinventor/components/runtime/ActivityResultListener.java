package com.google.appinventor.components.runtime;

import android.content.Intent;

public interface ActivityResultListener {
    void resultReturned(int i, int i2, Intent intent);
}
