package com.google.appinventor.components.runtime.util;

interface package-info {
}
